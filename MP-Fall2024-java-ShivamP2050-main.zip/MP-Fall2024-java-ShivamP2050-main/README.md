# CS 124 2024–2025 Machine Project (MP)

This is the Java starter code for the 2024–2025 CS 124 machine project (MP).
More information is available [here](https://cs124.org/MP/).
